import subprocess
import os

for i in range(25,26):
    k = str(i)
    if i == 23:
        k = "X_par1"

    if i == 24:
        k = "X_par2"

    if i == 25:
        k = "X"
    name = "plink.chr" + k + ".GRCh38.map"

    command = "python convert_to_shapeit.py " + name

    subprocess.call(command, shell=True)
