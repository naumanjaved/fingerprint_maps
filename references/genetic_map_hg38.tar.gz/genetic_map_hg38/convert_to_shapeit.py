import sys
import numpy as np
import pandas as pd

input_file = sys.argv[1]

input_map = pd.read_csv(input_file, sep = ' ', header=None)

input_map.columns = ['chr', 'rate', 'CM', 'pos']

input_map['CM'] = input_map['CM'].astype(float)
input_map['pos'] = input_map['pos'].astype(float)

input_map_diffs = input_map[['CM', 'pos']].diff(periods=1)

input_map_diffs['rate'] = input_map_diffs['CM'] / (input_map_diffs['pos'] / 1000000.00)

input_map['rate'] = input_map_diffs['rate']

input_map_shapeit = input_map[['pos', 'rate', 'CM']]

input_map_shapeit['pos'] = input_map_shapeit['pos'].astype(str)
input_map_shapeit['pos'] = input_map_shapeit['pos'].str.split('.')

input_map_shapeit['new_pos'] = input_map_shapeit['pos'].str[0]
input_map_shapeit = input_map_shapeit[['new_pos', 'rate', 'CM']]



input_map_shapeit.columns = ['position','COMBINED_rate(cM/Mb)','Genetic_Map(cM)']

## ignore first row since NA
input_map_shapeit = input_map_shapeit.iloc[1:]

input_map_shapeit.to_csv(sys.argv[1] + '.shapeit.txt', sep=' ', index=False, na_rep='NA', mode='w')


